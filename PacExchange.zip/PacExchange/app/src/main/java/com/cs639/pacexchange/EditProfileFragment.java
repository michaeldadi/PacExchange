package com.cs639.pacexchange;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.IOException;

import static android.app.Activity.RESULT_OK;

public class EditProfileFragment extends Fragment {

    ImageView mProfilePicture;
    ImageButton mSaveChanges;
    FloatingActionButton changeProfilePhotoButton;
    EditText mName, mEmail, mPassword, mPhoneNumber;

    StorageReference mStorageRef;
    FirebaseAuth mAuth;

    public EditProfileFragment() {
        //Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.edit_user_profile, container, false);

        mSaveChanges = view.findViewById(R.id.save_changes_button);
        changeProfilePhotoButton = view.findViewById(R.id.floatingActionButton);
        mProfilePicture = view.findViewById(R.id.imageview_account_profile);

        mName = view.findViewById(R.id.input_name);

        mAuth = FirebaseAuth.getInstance();
        mStorageRef = FirebaseStorage.getInstance().getReference();

        return view;
    }

    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        addButtonClickListeners();
    }

    private void addButtonClickListeners() {
        mSaveChanges.setOnClickListener(v -> {
            getFragmentManager().beginTransaction().replace(R.id.fragment_container, new UserProfileFragment()).commit();
        });
        changeProfilePhotoButton.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(getContext(),
                    Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        2000);
            } else {
                startGallery();
            }
        });
    }

    private void startGallery() {
        Intent cameraIntent = new Intent(Intent.ACTION_GET_CONTENT);
        cameraIntent.setType("image/*");
        if (cameraIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivityForResult(cameraIntent, 1000);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super method removed
        if (resultCode == RESULT_OK) {
            if (requestCode == 1000) {
                Uri returnUri = data.getData();
                //TODO: Complete below implementation
                //Firebase storage for uploaded image
                StorageReference filePath = mStorageRef.child("Images").child(returnUri.getLastPathSegment());
                filePath.putFile(returnUri).addOnSuccessListener(taskSnapshot -> {
                    Task<Uri> downloadURL = taskSnapshot.getMetadata().getReference().getDownloadUrl();

                }).addOnFailureListener(e -> Toast.makeText(getContext(),"Upload Failed",Toast.LENGTH_LONG).show());
                Bitmap bitmapImage = null;
                try {
                    bitmapImage = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), returnUri);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                mProfilePicture.setImageBitmap(bitmapImage);
            }
        }
    }
}
